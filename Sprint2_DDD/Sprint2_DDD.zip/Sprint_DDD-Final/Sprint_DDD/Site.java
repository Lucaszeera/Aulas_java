package Sprint_DDD;

public class Site {
public static void main(String[] args) {
	
	Candidato candidato1 = new Candidato("Lucas", "lucasinfocassis@gmail.com", 94232034, 19, "Solteiro", "08101054383", "Lucasszera", "2519915110");
	Vaga vaga1 = new Vaga("Gerente", "das 08:00 �s 16:00", 1800, "Rua Henrique Casela, 60", 3);
	Avaliador avaliador1 = new Avaliador("Cordeiro", "Cordeiro@gmail.com", 99873512, "profcordeiro", "12314123a", "FIAP", "Professor");
	Empresa empresa1 = new Empresa("Fiap_bank", "Fiap@fiap.com", 94232304, "fiapempresa", "21591246", 0231346);
	Suporte suporte1 = new Suporte("Lucas", "lucas@gmail.com", 94354, "Lucasdev", "251919", 94013);
	
}}
